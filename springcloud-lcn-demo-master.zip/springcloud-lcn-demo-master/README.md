# springcloud LCN分布式事务v4.0 示例demo


## 使用说明见wiki


[springcloud-lcn-demo.wiki](https://github.com/codingapi/springcloud-lcn-demo/wiki)