package com.example.demo.service;

/**
 * Created by lorne on 2017/6/26.
 */
public interface DemoService {



    int save();

}
